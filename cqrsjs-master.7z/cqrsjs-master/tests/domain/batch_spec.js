/// <reference path="../helpers/loadForTest.ts" />
eval(loadModule("framework"));
eval(loadModule("domain"));
var CQRSjs;
(function (CQRSjs) {
    var test;
    (function (test) {
        describe("a gym aggregate root", function () {
            it("should be an instance of AggregateRoot", function () {
                var testGym = new CQRSjs.Domain.Gym(CQRSjs.IDGenerator.generate());
                expect(testGym instanceof CQRSjs.Domain.AggregateRoot).toBeTruthy();
            });
        });
        describe("an aggregate root", function () {
        });
        describe("an aggregate root", function () {
            it("should stuff", function () {
                expect(1).toBe(1);
            });
        });
    })(test = CQRSjs.test || (CQRSjs.test = {}));
})(CQRSjs || (CQRSjs = {}));

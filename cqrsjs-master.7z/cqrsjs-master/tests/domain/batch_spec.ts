/// <reference path="../helpers/loadForTest.ts" />
eval(loadModule("framework"));
eval(loadModule("domain"));

module CQRSjs.test{

    describe("a gym aggregate root", function(){

        it("should be an instance of AggregateRoot", function(){
            var testGym = new Domain.Gym(IDGenerator.generate());

            expect(testGym instanceof Domain.AggregateRoot).toBeTruthy();
        });

    });

    describe("an aggregate root", function(){
        
    })

}
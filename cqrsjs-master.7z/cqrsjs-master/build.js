var ref = require("./ref.js");

ref.update();
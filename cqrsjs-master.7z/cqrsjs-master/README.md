CQRSjs
---------------------------------------
A CQRS framework for javascript - node, front end, or wherever you want it!
Built with TypeScript for ease with integrating into any TypeScript project.


Split up carefully into folders and very accepting of modification, this project lets you package up what you need for your specific needs without constraining you to a single way of doing things.


build
-----------------------
run build.bat
to edit dependencies between folders, check the refs.refs file. 
Avoid circular dependencies!


test
-----------------------
uses jasmine.
run test.bat



https://www.imperiojs.com/
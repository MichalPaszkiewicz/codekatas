module CQRSjs.Domain{

    export class Batch extends AggregateRoot{

        

    }

}
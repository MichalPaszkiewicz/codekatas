module CQRSjs.Domain{

    export class Customer extends AggregateRoot{
        
    }

}
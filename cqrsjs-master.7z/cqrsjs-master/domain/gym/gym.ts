module CQRSjs.Domain{

    export class Gym extends AggregateRoot{
        
    }

}